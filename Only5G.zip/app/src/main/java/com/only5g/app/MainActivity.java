package com.only5g.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final String[][] TARGETS = {
            {"com.android.phone", "com.android.phone.settings.RadioInfo"},
            {"com.android.phone", "com.android.phone.RadioInfo"},
            {"com.android.settings", "com.android.settings.RadioInfo"},
            {"com.android.settings", "com.android.settings.network.telephony.RadioInfo"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (openPhoneInfo()) {
            finish();
            return;
        }
        buildFallbackUi();
    }

    private boolean openPhoneInfo() {
        for (String[] t : TARGETS) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(t[0], t[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Exception ignored) {
            }
        }
        try {
            Intent i = new Intent("android.provider.Telephony.SECRET_CODE",
                    Uri.parse("android_secret_code://4636"));
            sendBroadcast(i);
            return true;
        } catch (Exception ignored) {
        }
        return false;
    }

    private void buildFallbackUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(60, 60, 60, 60);
        root.setBackgroundColor(Color.parseColor("#121212"));

        TextView title = new TextView(this);
        title.setText("Only 5G");
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);

        TextView msg = new TextView(this);
        msg.setText("Phone info screen khuli nahi. Retry karo, athva dialer ma *#*#4636#*#* dial karo.");
        msg.setTextSize(16);
        msg.setTextColor(Color.LTGRAY);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 30, 0, 30);

        Button retry = new Button(this);
        retry.setText("Open Phone info");
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (openPhoneInfo()) finish();
            }
        });

        Button dialer = new Button(this);
        dialer.setText("Open Dialer");
        dialer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode("*#*#4636#*#*")));
                startActivity(i);
            }
        });

        root.addView(title);
        root.addView(msg);
        root.addView(retry);
        root.addView(dialer);
        setContentView(root);
    }
}
